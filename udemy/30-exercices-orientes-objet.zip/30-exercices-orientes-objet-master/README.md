# 30 Exercices Orientés Objet avec Python
Code et ressources pour [**30 Exercices Orientés Objets avec Python**](https://www.docstring.fr/formations/30-exercices-orientes-objets-avec-python/)
