class Livre:
    prix = 9.99


harry_potter = Livre()