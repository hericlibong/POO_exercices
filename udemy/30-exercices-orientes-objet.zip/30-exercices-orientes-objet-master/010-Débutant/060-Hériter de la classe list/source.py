class ListeCustom:
    pass


liste = ListeCustom()