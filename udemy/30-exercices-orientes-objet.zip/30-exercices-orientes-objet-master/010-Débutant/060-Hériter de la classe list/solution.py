class ListeCustom(list):
    pass


liste = ListeCustom()
liste.append(5)