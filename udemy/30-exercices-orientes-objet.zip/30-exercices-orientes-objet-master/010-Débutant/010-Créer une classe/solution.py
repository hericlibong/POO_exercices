class Livre:
    pass


harry_potter = Livre()
