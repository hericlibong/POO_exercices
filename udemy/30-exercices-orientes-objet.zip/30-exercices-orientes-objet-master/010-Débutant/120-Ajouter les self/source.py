class Cube:
    def __init__(x=5, y=2, z=7):
        x = x
        y = y
        z = z

    def move_x():
        x += 1


mon_cube = Cube()
mon_cube.move_x()