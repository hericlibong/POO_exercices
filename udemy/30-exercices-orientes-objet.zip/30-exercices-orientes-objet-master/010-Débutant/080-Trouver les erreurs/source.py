class Geometry:
	def init(self, x=0, y=0):
		self.x = pos_x
		self.y = y
		self.z = z

sphere = Geometry
print(sphere.x)
print(sphere.y)
print(sphere.z)