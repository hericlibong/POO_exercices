class Magicien:
    def __init__(self, prenom, nom):
        self.prenom = prenom
        self.nom = nom
        self.puissance = 80


class Gobelin:
    def __init__(self, prenom, nom):
        self.prenom = prenom
        self.nom = nom
        self.puissance = 20


class Chevalier:
    def __init__(self, prenom, nom):
        self.prenom = prenom
        self.nom = nom
        self.puissance = 70