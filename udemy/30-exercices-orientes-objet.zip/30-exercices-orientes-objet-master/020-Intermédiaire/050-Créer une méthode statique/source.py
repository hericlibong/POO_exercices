class Chanson:
    paroles = """Joyeux anniversaire,
Joyeux anniversaire,
Joyeux anniversaire {prenom},
Joyeux anniversaire."""

    def chante_pour():
        pass


print(Chanson.chante_pour(prenom="Paul"))