class Voiture:
    pass


voiture = Voiture(marque="Mazda", prix=30000)
voiture.changer_prix(35000)