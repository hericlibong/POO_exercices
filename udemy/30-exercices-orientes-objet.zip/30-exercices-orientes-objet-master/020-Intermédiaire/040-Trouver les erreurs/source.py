def Voiture:
    class _init_(self):
        marque = "Mazda"
        couleur = "Rouge"

    def recuperer_couleur():
        return couleur


mazda_rouge = Voiture
couleur = mazda_rouge.recuperer_couleur()